# the Mote project (http://mote.sourceforge.net/)

import random
import string

names = []
digraphs = [
        "aa",'ab','ac','ad','ae','af','ag','ah','ai','aj','ak','al','am','an','ao','ap','aqu','ar','as','at','au','av','aw','ax','ay','az',
        'ba','be','bi','bl','bo','bu','ca','ce','ch','ck','cr','cy','f','vi','ion',
        'da','de','di','chr','bor', 'th','gr','ium','om', 'hu','kry','pt'
        "la",  "ve",  "ta",  "re",  "or",  "za",  "us",
        "te",  "ce",  "at",  "a",   "e",   "o",   "le",  "fa",
        "he",  "na",  "ar",  "to",  "oi",  "ne",  "no",  "ba",
        "bo",  "ha",  "ve",  "va",  "ax",  "is",  "or",  "in",
        "mo",  "on",  "cra", "ud",  "sa",  "tu",  "ju",  "pi",
        "mi",  "gu",  "it",  "ob",  "os",  "ut",  "ne",  "as",
        "en",  "ky",  "tha", "um",  "ka",  "qt",  "zi",  "ou",
        "ga",  "dro", "dre", "pha", "phi", "sha", "she", "fo",
        "cre", "tri", "ro",  "sta", "stu", "de",  "gi",  "pe",
        "the", "thi", "thy", "lo",  "ol",  "clu", "cla", "le",
        "di",  "so",  "ti",  "es",  "ed",  "po",  "ni",
        "ex",  "un",  "pho", "ci",  "ge",  "se",  "co",
    ]

numDGs = len(digraphs) - 1

def checkName(name):
    vowels = 0
    samechar = 0
    lastchar = "*"
    
    i = 0
    while i < len(name):
        c = name[i]
        
        # Abort if more then two vowels are found together
        if c in ('a', 'e', 'i', 'o', 'u'): 
            vowels = vowels + 1
        else:
            vowels = 0;
        if vowels == 3:
            return 0
        
        # Abort if three same letters are found together    
        if c == lastchar:
            samechar = samechar + 1
        else:
            samechar = 0
        if samechar == 2:
            return 0
            
        lastchar = c

        i = i + 1
        
    return 1
   
def isDuplicated(name):
    # Check if name was already used
    if name in names:
        return 1
    return 0
    
def getName(NameType = 'Planet'):
    # Create names with 2-3 syllables
    length = 2 + int(random.random() * 3)
    
    # But sometimes use 4 syllables
    if int(random.random() * 15) == 1:
        length = length + 1
        
    # Repeat until the generated name is ok
    nameok = 0
    while not nameok:
        name = ""
        i = 0
        while i < length:
            ok = 0
            while not ok:
                ok = 1
                
                # Get a random syllable and make sure that no
                # three-letter syllable is used as the last one
                dgr = digraphs[int(random.random() * numDGs)]
                if (i == length - 1) and (len(dgr) > 2):
                    ok = 0
                  
            # Add the syllable to the name
            name = name + dgr
            
            # Repeat
            i = i + 1
        
        # Check if name is pronounceable and unique
        nameok = checkName(name) and not isDuplicated(name)
                 
    # Add the name to the cache so further names can be checked for
    # signleness.
    name = name.capitalize()

    if(NameType == 'Star'):
        nameFormat = random.randint(0,10)
        
        GreekAlphabet = ['Alpha','Beta','Gamma','Delta','Epsilon','Zeta','Eta','Iota','Kappa','Lambda','Mu','Nu','Xi','Omicron','Pi','Rho','Sigma',
                 'Tau','Upsilon','Phi','Chi','Psi','Omega']

        GodNames = ['Andromeda','Antila','Apus','Aquarius','Aquila','Ara','Aries','Auriga','Bootes','Caelum','Camelopardalis','Cancer','Canes Venatici', 'Canis Major',
                    'Canis Minor','Capricornus','Carina','Cassiopeia','Centaurus','Cepheus','Cetus','Chamaeleon','Circinus','Columbia','Coma Berenices', 'Corona Australis',
                    'Corona Borealis','Corvus','Crater','Cygnus','Delphinus','Dorado','Draco','Equuleus','Eridanus','Fornax','Gemini','Grus','Hercules', 'Horlogium', 'Hydra',
                    'Hydrus','Indus','Lacerta','Leo','Leo Minor','Lepus','Libra','Lupus','Lynx','Lyra','Mensa','Microscopium','Monoceros','Musca','Norma','Octans',
                    'Ophiuchus','Orion','Pavo','Pegasus','Perseus','Phoenix','Pictor','Pisces','Piscis Austrinus','Puppis','Pyxis','Reticulum','Sagitta','Sagittarus',
                    'Scorpius','Sculptor','Scutum','Serpens','Taurus','Telescopium','Triangulum','Tucana','Ursa Major','Ursa Minor','Vela','Virgo','Volans','Vulpecula',
                    'Centurion','Hunter']
        
        GreekAlphabet = ['Alpha','Beta','Gamma','Delta','Epsilon','Zeta','Eta','Iota','Kappa','Lambda','Mu','Nu','Xi','Omicron','Pi','Rho','Sigma',
             'Tau','Upsilon','Phi','Chi','Psi','Omega']
        
        SunAlph = GreekAlphabet[random.randint(0,len(GreekAlphabet) - 1)]

        if(nameFormat == 0):
            GreekAlphIdx = random.randint(0,len(GreekAlphabet) - 1)
            GodNameIdx = random.randint(0,len(GodNames) - 1)
            name = GodNames[GodNameIdx] + '-' + GreekAlphabet[GreekAlphIdx]

        elif(nameFormat == 1):
            GodNameIdx = random.randint(0,len(GodNames) - 1)
            Num = random.randint(42,999)
            name = GodNames[GodNameIdx][0:3] + '-' + str(Num)

        elif(nameFormat == 2):
            GreekAlphIdx = random.randint(0,len(GreekAlphabet) - 1)
            Num = random.randint(42,999)
            name = GreekAlphabet[GreekAlphIdx] + '-' + str(Num)
        elif(nameFormat == 3):
            GreekAlphIdx = random.randint(0,len(GreekAlphabet) - 1)
            GodNameIdx = random.randint(0,len(GodNames) - 1)
            name = GreekAlphabet[GreekAlphIdx] + '-' + GodNames[GodNameIdx]
        elif nameFormat > 3:
            name = name + '-' + SunAlph
            
    elif(NameType == "Planet"):
        name = name #Needs to do something here
    else:
        name = ''

    names.append(name)
    return name

print("    NameGenerator.py")
