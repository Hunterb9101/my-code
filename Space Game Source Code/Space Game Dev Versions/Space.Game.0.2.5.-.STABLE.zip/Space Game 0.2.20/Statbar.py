from tkinter import *
from Window import *

################################
#       Stat Bar Class!        #
################################

class Statbar:
    Info = []
    Active = []
    Attrs = ['Name','Align','Height','Width','Offset','Visibility','Background']
    
    def __init__(self,name,align="TL",height='100',width='100',offset=(0,0), visibility='True',bg="#000000"):
        Compile = []

        Compile.append(name)
        Compile.append(align)
        Compile.append(height)
        Compile.append(width)
        Compile.append(offset)
        Compile.append(visibility)
        Compile.append(bg)
        
        Statbar.Info.append(Compile)
        Statbar.Load(name)
        
    def Load(name):
        SbData=Statbar.Info[Statbar.getName(name)]
        statbar = Frame(Window.root,bg=Statbar.Info[Statbar.getName(name)][Statbar.getAttrNum("Background")])
        Statbar.Active.append(statbar)

        #Sizing the Statbar Correctly
        Size = (SbData[Statbar.getAttrNum('Width')],SbData[Statbar.getAttrNum('Height')])
        
        if Size[0].find('winSize') != -1:
            Subtract = 0
            Equation = Size[0].split('*')
            if '-' in Size[0]:
                Equation = Equation[1].split('-')[0]
                SubtEquation = Size[0].split('-')
                Subtract = SubtEquation[1]
            try:
                Equation = Equation[1]
            except IndexError:
                Equation = Equation
            sbWidth = int(Window.root.winfo_screenwidth() * float(Equation) - int(Subtract))   
        else: sbWidth = Size[0]

        if Size[1].find('winSize') != -1:
            Subtract = 0
            Equation = Size[1].split('*')
            if '-' in Size[1]:
                Equation = Equation[1].split('-')[0]
                SubtEquation = Size[1].split('-')
                Subtract = SubtEquation[1]
                print(Equation + " - " + Subtract)
            sbHeight = int(Window.root.winfo_screenheight() * float(Equation[1])- int(Subtract))
        else: sbHeight = Size[1]

        #Aligning the Statbar
        Align = SbData[Statbar.getAttrNum('Align')]
        Pos = (0,0)
        offset = SbData[Statbar.getAttrNum('Offset')]
                                    ##      Width                  Height               
        if Align   == "TL":  Pos = (offset[0], offset[1])
        elif Align == "TR":  Pos = (Window.Size[0] - sbWidth + offset[0], offset[1])
        elif Align == "TC":  Pos = (int(Window.Size[0]/2) + offset[0], offset[1])
                       
        elif Align == "CL":  Pos = (int(Window.Size[1]/2),0)
        elif Align == "C" :  Pos = (int(Window.Size[0]/2),int(Window.Size[1]/2))
        elif Align == "CR":  Pos = (int(Window.Size[0]/2),Window.Size[1])
                       
        elif Align == "BL":  Pos = (Window.Size[0]       ,0)
        elif Align == "BC":  Pos = (Window.Size[0],       int(Window.Size[1]/2))

        else: print("ERROR placing Statbar!")
        statbar.place(x=Pos[0],y=Pos[1],width = sbWidth, height = sbHeight)
        statbar.lift()
      
    def getName(name):
        for cntr in range(len(Statbar.Info)):
            if Statbar.Info[cntr][0] == name: return cntr      
            if cntr == (len(Statbar.Info)-1): return -1

    def getAttrNum(attr):
        for cntr in range(len(Statbar.Attrs)):
            if attr == Statbar.Attrs[cntr]: return cntr
 
            if cntr == (len(Statbar.Attrs) - 1): return -1
            
