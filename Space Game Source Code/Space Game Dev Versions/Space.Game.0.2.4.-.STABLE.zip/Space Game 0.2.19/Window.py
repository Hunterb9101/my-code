from tkinter import *
from Tile import *
import NameGenerator
import Parser
import Weighted_Percent
import Utils
import random

gGlobals = Parser.Globals
gVersion = Utils.GlobalByName("Version")
gIconPath = Utils.GlobalByName("IconPath")
gBoardSize = Utils.GlobalByName("BoardSize")
gTileSize = Utils.GlobalByName("TileSize")
gFullscreenState = False
gPadding = Utils.GlobalByName("Padding") #[70,0,0,280] #Top,Right,Down,Left
gSunThresholds = [12,50,38]

################################
#          Game Board          #
################################
class Window:
    root = Tk() # Main window
    root.title("Space Game " + gVersion)
    root.wm_iconbitmap(gIconPath)
    Size = [root.winfo_screenwidth(),root.winfo_screenheight()]

    main = Canvas(root, width=root.winfo_screenwidth() * .98, height= root.winfo_screenheight() * .98,bg="#000000") #-#Canvas
    main.grid(row=0, column=0, sticky='nswe')                                                                       #-#Canvas
    
    def Onclick(event,debug=True):
        offsetX = - gPadding[3] 
        offsetY = - gPadding[0]
        BoardSizePx = [gBoardSize[0]*gTileSize, gBoardSize[1]*gTileSize]
        formulax = event.x + offsetX  + Window.hScroll.get()[0] * (BoardSizePx[0] + gPadding[3])# Gets EXACT pixel on X plane
        formulay = event.y + offsetY  + Window.vScroll.get()[0] * (BoardSizePx[1] + gPadding[0])# Gets EXACT pixel on Y plane  
        coord = (int((formulax)/gTileSize) + 1,int((formulay)/gTileSize) + 1) #gets grid number
        Tile.get(coord[0],coord[1])

        if debug:
            print("")
            print("    X:" + str(formulax) + ", MAX: " + str(gBoardSize[0]*gTileSize))
            print("    Y:" + str(formulay) + ", MAX: " + str(gBoardSize[1]*gTileSize))
            print("")

    def toggle_fullscreen(event=None):
        global gFullscreenState
        gFullscreenState = not gFullscreenState
        Window.root.attributes("-fullscreen", gFullscreenState)
        if not gFullscreenState:
            l, h = Window.root.winfo_screenwidth(), Window.root.winfo_screenheight()
            Window.root.geometry("%dx%d+0+0" % (l, h))
            
    def end_fullscreen(event=None):
        global gFullscreenState
        gFullscreenState = False
        Window.root.attributes("-fullscreen", False)

    def on_mousewheel(event=None):
        Window.main.yview_scroll(int(-1*(event.delta/120)), "units")

    def on_arrowkey(event=None, x=0, y=0):
        Window.main.xview_scroll(int(x), "units")
        Window.main.yview_scroll(-1*int(y), "units")
        
    def refresh_winVals():
        Window.screenSize[0] = Window.root.winfo_screenwidth()
        Window.screenSize[1] = Window.root.winfo_screenheight()
        
        
    def Generate(): # Creates Board for gameplay
        for cntr in range(gBoardSize[0] * gBoardSize[1]): #Creates a "blank slate" for generation
            Tile(0,name = NameGenerator.getName(NameType=XMLTileData[0][Tile.getTag('CreateName')]))

        #Add gPadding
        TLgPaddingCoords=[(0,0),(1,0),(1,1),(0,1)]
        BRgPaddingCoords=[(gBoardSize[0]*gTileSize+gPadding[0]           ,gBoardSize[1]*gTileSize           +gPadding[3]),
                         (gBoardSize[0]*gTileSize+gPadding[0]+gPadding[1],gBoardSize[1]*gTileSize+gPadding[2]+gPadding[3]),
                         (gBoardSize[0]*gTileSize+gPadding[0]+gPadding[1],gBoardSize[1]*gTileSize+gPadding[2]+gPadding[3]),
                         (gBoardSize[0]*gTileSize+gPadding[0]           ,gBoardSize[1]*gTileSize           +gPadding[3])]
        
        if(gPadding[2] == 0):
            BRgPaddingCoords[0] = (0,0)
            BRgPaddingCoords[1] = (0,0)
            BRgPaddingCoords[2] = (0,0)
            BRgPaddingCoords[3] = (0,0)
            
        Window.main.create_polygon(BRgPaddingCoords)
        Window.main.create_polygon(TLgPaddingCoords)
        
        # Generate Sun
        CenterAppx = (int(gBoardSize[0]/2),int(gBoardSize[1]/2))
        Stars = Tile.getByAttr('Type','Star')
        TileType = Weighted_Percent.Random(gSunThresholds) + Stars[0] #Stars[0] is the first star found
        Tile.set(CenterAppx[0],CenterAppx[1],TileType,refCoords = -1, name = NameGenerator.getName(NameType=XMLTileData[TileType][Tile.getTag('CreateName')]))

        # Generate Planets
        for cntr in range(int(XMLTileData[Tile.getByAttr('Type','Planet','integer')][Tile.getTag('SpawnMax')])):
            Coords = (random.randint(0,gBoardSize[0]),random.randint(0,gBoardSize[1]))
            
            passed = False
            while not passed:
                if Tile.isBordering(Coords[0],Coords[1],Tile.getByAttr('Type','Planet','integer'),1):
                    Coords = (random.randint(0,gBoardSize[0]),random.randint(0,gBoardSize[1]))
                    passed = False
                passed = True
            Tile.set(Coords[0],Coords[1],Tile.getByAttr('Name','Planet','integer'),refCoords = -1, name =
                     NameGenerator.getName(NameType = XMLTileData[Tile.getByAttr('Type','Planet','integer')][Tile.getTag('CreateName')]))

        # Generate Asteroids
        for cntr in range(int(XMLTileData[Tile.getByAttr('Name','Asteroid Field','integer')][Tile.getTag('SpawnMax')]) + random.randint(-2,2)):
            passed = False
            while not passed:
                Coords = (random.randint(0,gBoardSize[0]),random.randint(0,gBoardSize[1]))
                if Tile.get(Coords[0],Coords[1],returnval='TileType') != 0:
                    passed = False
                else:
                    passed = True
            Tile.set(Coords[0],Coords[1],Tile.getByAttr('Name','Asteroid Field','integer'),refCoords = -1)

            
        row = 1 
        column = 1
        while column <= gBoardSize[1]:
            if row > gBoardSize[0]:
                if column == gBoardSize[1]:
                    break
                row = 1
                column = column + 1
                
            ImgCoord = ((0,0),
                       ((row - 1) * gTileSize + 35  + gPadding[3], (column - 1) * gTileSize + 35   + gPadding[0]),
                       ((row - 1) * gTileSize + 70  + gPadding[3], (column -1)  * gTileSize + 70   + gPadding[0]),
                       ((row - 1) * gTileSize + 105 + gPadding[3], (column -1)  * gTileSize + 105  + gPadding[0]))
            
            TLPolyCoord = ((row - 1) * gTileSize + gPadding[3],(column - 1) * gTileSize  + gPadding[0])
            PolyCoord = ((0,0),
                        ( ## Size 1 ##
                            ((row - 1) * gTileSize  + gPadding[3], column      * gTileSize  + gPadding[0]), 
                            ( row      * gTileSize  + gPadding[3], column      * gTileSize  + gPadding[0]),
                            ( row      * gTileSize  + gPadding[3],(column - 1) * gTileSize  + gPadding[0])),
                         
                        ( ## Size 2 ##
                            ((row - 1) * gTileSize  + gPadding[3],(column + 1) * gTileSize  + gPadding[0]),
                            ((row + 1) * gTileSize  + gPadding[3],(column + 1) * gTileSize  + gPadding[0]),
                            ((row + 1) * gTileSize  + gPadding[3],(column - 1) * gTileSize  + gPadding[0])),
                        ( ## Size 3 ##
                            ((row - 1) * gTileSize + gPadding[3],(column + 2) * gTileSize  + gPadding[0]),
                            ((row + 2) * gTileSize + gPadding[3],(column + 2) * gTileSize  + gPadding[0]),
                            ((row + 2) * gTileSize + gPadding[3],(column - 1) * gTileSize  + gPadding[0])))

            TileArrayNum = Tile.ArrayNum(row,column)
            TileType = Tile.Data[TileArrayNum][0]
            TileRef = Tile.Data[TileArrayNum][1]
            
            if(TileRef == -1):
                Graphics = Tile.getGraphics(TileType)
                Window.main.create_polygon(TLPolyCoord,PolyCoord[int(XMLTileData[TileType][Tile.getTag('Size')])],fill = Graphics[0])
                Window.main.create_image(ImgCoord[int(XMLTileData[TileType][Tile.getTag('Size')])], image=Graphics[1])
                
                Tile.SetArea(row,column,TileType,XMLTileData[TileType][Tile.getTag('Size')])
                
            Window.main["scrollregion"]=Window.main.bbox(ALL) # Makes scrollbar work
            row = row + 1
    
    root.grid_rowconfigure(0, weight=1)   #Grid Sizing behaviors
    root.grid_columnconfigure(0, weight=1)#Grid Sizing behaviors
    
    hScroll = Scrollbar(root, orient=HORIZONTAL, command=main.xview)#--------#
    hScroll.grid(row=1, column=0, sticky='we')                                    #----- Scrollbars
    vScroll = Scrollbar(root, orient=VERTICAL, command=main.yview)           #----- Scrollbars
    vScroll.grid(row=0, column=1, sticky='ns')                           #--------#
    main.configure(xscrollcommand=hScroll.set, yscrollcommand=vScroll.set) # Attaches Scrollbars to Canvas

    #################
    #     Keys      #
    #################
    
    main.bind("<Button-1>",Onclick) #Binds Left-Mouse to Screen, giving Event x and y coordinates and handler
    root.bind("<F11>", toggle_fullscreen)
    root.bind("<Escape>", end_fullscreen)
    root.bind_all("<MouseWheel>", on_mousewheel)
    root.bind_all("<Left>", lambda event: Window.on_arrowkey(x=-1))
    root.bind_all("<Right>",lambda event: Window.on_arrowkey(x=1))
    root.bind_all("<Down>", lambda event: Window.on_arrowkey(y=-1))
    root.bind_all("<Up>",   lambda event: Window.on_arrowkey(y=1))
