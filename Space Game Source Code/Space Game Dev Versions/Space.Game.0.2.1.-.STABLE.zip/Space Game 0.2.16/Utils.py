import datetime
import Parser

print("    Utils.py")

def Stamp():
    currenttime = datetime.datetime.now()
    timeH   = currenttime.hour
    timeM   = currenttime.minute
    timeS   = currenttime.second
    timeDMY = datetime.date.today().strftime("%d/%m/%Y")
    timeArr = timeDMY.split('/')
    timeEnc = timeS + 60*timeM + 3600*timeH + 3600*24*int(timeArr[1])
    print(str(timeH) + ":" + str(timeM) + "." + str(timeS) + " " + str(timeDMY))
    print("Time in seconds: " + str(timeEnc))

def GlobalByName(globalName):
    Globals = Parser.Globals
    for cntr in range(len(Globals)):
        if globalName in Globals[cntr][0]:
            return Globals[cntr][1]
    else:
        print("ERROR: Can't find global: " + globalName)
    
