import Parser
import Utils
import random

from tkinter import *

XMLTileData  = Parser.XMLDataParser.TileData
XMLDataTags  = Parser.DataTags
XMLTileNames = Parser.TileNames

gThresholds = []
gBoardSize = Utils.GlobalByName('BoardSize')
gTileSize = Utils.GlobalByName('TileSize')
gPadding = Utils.GlobalByName('Padding')
gImagePath = Utils.GlobalByName('ImagePath')

################################
#           Tile Data          #
################################
            
class Tile:
    Images = []
    ObjCount = []
    Data=[]

    cntr = 0
    while cntr < len(XMLTileData):
        ObjCount.append(0)
        cntr += 1
                   
    def __init__(self,tiletype=None,refCoords = None):
        Compile = []
            
        if tiletype == None: Compile.append(0)
        else: Compile.append(tiletype)

        if refCoords == None: Compile.append(-1)
        else: Compile.append(refCoords)

        Compile.append(XMLTileData[0][Tile.getTag('CreateName')])
            
        Tile.Data.append(Compile)
        
    def set(iRow,iColumn,tileType, refCoords = None, ChangeNameTo = None):
        TileArrayNum = Tile.ArrayNum(iRow,iColumn)
        Tile.Data[TileArrayNum][0] = tileType
        
        if refCoords == None: Tile.Data[TileArrayNum][1] = -1
        else: Tile.Data[TileArrayNum][1] = refCoords

        if (ChangeNameTo != None): Tile.Data[TileArrayNum][2] = ChangeNameTo
        
    def SetArea(iTLRow,iTLColumn,tiletype, iSize):
        TileArrayNum = Tile.ArrayNum(iTLRow,iTLColumn)        
        if (int(iSize) == 2):
            Tile.set(iTLRow ,iTLColumn + 1,tiletype,TileArrayNum)
            
            Tile.set(iTLRow + 1,iTLColumn    ,tiletype,TileArrayNum)
            Tile.set(iTLRow + 1,iTLColumn + 1,tiletype,TileArrayNum)
            
        elif (int(iSize) == 3):
            Tile.set(iTLRow, iTLColumn + 1, tiletype,TileArrayNum)
            Tile.set(iTLRow, iTLColumn + 2, tiletype,TileArrayNum)
                
            Tile.set(iTLRow + 1, iTLColumn,     tiletype,TileArrayNum)
            Tile.set(iTLRow + 1, iTLColumn + 1, tiletype,TileArrayNum)
            Tile.set(iTLRow + 1, iTLColumn + 2, tiletype,TileArrayNum)
                
            Tile.set(iTLRow + 2, iTLColumn,     tiletype,TileArrayNum)
            Tile.set(iTLRow + 2, iTLColumn + 1, tiletype,TileArrayNum)
            Tile.set(iTLRow + 2, iTLColumn + 2, tiletype,TileArrayNum)
            
    def get(row,column,returnval = None):
        try:
            TileArrayNumRef = Tile.ArrayNum(row,column)
            TileArrayNum = TileArrayNumRef
            TileType = Tile.Data[TileArrayNum][0]
            
            if(Tile.Data[TileArrayNum][1] != -1):
                TileArrayNum = Tile.Data[TileArrayNum][1]

            if returnval == None:    
                print("Tile #: " + str(TileArrayNumRef) + ' (' + str(row) + ', ' + str(column) + ')')
                print("    Tile Type: " + str(TileType))
                print("    Regular Name: " + XMLTileData[TileType][Tile.getTag("Name")])
                print("    Special Name: " + str(Tile.Data[TileArrayNum][2]) + " (" + (XMLTileData[TileType][Tile.getTag('CreateName')] + " Name)"))
                print("    Reference Coords: " + str(Tile.Data[TileArrayNumRef][1]))

            if returnval == 'TileType':
                return TileType
        except IndexError:
            print("The data couldn't be retrieved because it was out of range.")
    def getTag(name):
        for cntr in range(len(XMLDataTags)):
            if name == XMLDataTags[cntr]:
                return cntr
            if cntr == len(XMLDataTags) - 1:
                return -1
                print("Can't find",name,"in the parsable data tags list")
                
    def getTagData(TileType,Tag): return XMLTileData[TileType][Tile.getTag(Tag)]
        
    def getByAttr(category,data,returntype = 'list'):
        filtered = []
        for cntr in range(len(XMLTileData)):
            if(XMLTileData[cntr][Tile.getTag(category)] == data):
                if returntype == 'list':
                    filtered.append(cntr)
                elif returntype == 'integer':
                    return cntr
        return filtered

    def getGraphics(TileType):
        try:
            ImgDecider = random.randint(0,len(Tile.Images[TileType]) - 1)
            image = Tile.Images[TileType][ImgDecider]
        except TypeError:
            image = Tile.Images[TileType]

        Color = XMLTileData[TileType][Tile.getTag('BgColor')]
        
        if "[" in str(XMLTileData[TileType][Tile.getTag('BgColor')]) and "]" in str(XMLTileData[TileType][Tile.getTag('BgColor')]):
            Color = XMLTileData[TileType][Tile.getTag('BgColor')][1:-1]
            Color = Color.split(',')
            for cntr in range(len(Color)):
                Color[cntr] = int(Color[cntr][2:],16)
            Color = Utils.new_gradient(Color)
            Color = Color[random.randint(0,len(Color)-1)]
        return [Color,image]
    
    def getGraphicsCoords(row,column,size,returnType = "img"):
        size = int(size)
        ImgCoord = (int((row - 1) * gTileSize + gTileSize*size/2 + gPadding[3]),int((column - 1) * gTileSize + gTileSize*size/2 + gPadding[0]))
        
        PolyCoord =(
                (row - 1) * gTileSize + gPadding[3],(column - 1) * gTileSize  + gPadding[0],
                (row - 1)        * gTileSize  + gPadding[3], (column - 1 + size) * gTileSize  + gPadding[0], 
                (row - 1 + size) * gTileSize  + gPadding[3], (column - 1 + size) * gTileSize  + gPadding[0],
                (row - 1 + size) * gTileSize  + gPadding[3], (column - 1)        * gTileSize  + gPadding[0])
        
        if returnType == "poly": return PolyCoord; print("Polygon Coordinates returned")
        else: return ImgCoord; print("Image Coordinates returned")
    
    def isBordering(iRow,iColumn,iTargetType,iRange):
        Ranges = [(0,0),
                  (-1,1),(0,1),(1,1),(-1,0),(1,0),(-1,-1),(0,-1),(1,-1)]
        Borders = []
        if iRange == 1:
            for cntr in range(len(Ranges[1])):
                if iRow + 1 < gBoardSize[0] or iColumn + 1 < gBoardSize[0]:
                    try:
                        Borders.append(Tile.get(iRow + Ranges[cntr][0],iColumn + Ranges[cntr][1],returnval = 'TileType'))
                    except IndexError:
                        pass
        try:
            if(Borders.index(iTargetType) != -1):
                return True
        except ValueError:
            return False
        
    def ArrayNum(row,column): TileArrayNum = (column - 1) * gBoardSize[0] + row - 1; return TileArrayNum #Tile Array Number Reference function for formula

    def FinishParsing():
        for cntr in range(len(XMLTileData)): gThresholds.append(XMLTileData[cntr][2]) #Gets Weighted percentage rates for spawning

        for cntr in range(len(XMLTileData)):# Gets Images for tiles and puts it into Tile.Images
            Art = Tile.getTag('Art')
            if (XMLTileData[cntr][Tile.getTag('Art')].find(',') == -1): #If there is only one image
                Tile.Images.append(PhotoImage(file=gImagePath + XMLTileData[cntr][Art])) 
            else: #Multiple images
                XMLTileData[cntr][Tile.getTag('Art')] = XMLTileData[cntr][Art].split(' , ')
                Compile = []
                for cntr2 in range(len(XMLTileData[cntr][Art])):
                    Compile.append(PhotoImage(file=gImagePath + XMLTileData[cntr][Art][cntr2]))
                Tile.Images.append(Compile)
